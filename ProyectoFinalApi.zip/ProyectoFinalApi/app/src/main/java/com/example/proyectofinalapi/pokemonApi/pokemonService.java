package com.example.proyectofinalapi.pokemonApi;

import com.example.proyectofinalapi.modelos.pokemonRespuesta;

import retrofit2.Call;
import retrofit2.http.GET;

public interface pokemonService {
    @GET("pokemon")
    Call<pokemonRespuesta> obtenerListaPokemon();


}
