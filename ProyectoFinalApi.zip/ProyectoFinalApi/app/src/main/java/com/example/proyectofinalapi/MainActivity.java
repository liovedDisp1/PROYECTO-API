package com.example.proyectofinalapi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import com.example.proyectofinalapi.modelos.Pokemon;
import com.example.proyectofinalapi.modelos.pokemonRespuesta;
import com.example.proyectofinalapi.pokemonApi.pokemonService;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "POKEDEX";

    private Retrofit retrofit;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        retrofit = new Retrofit.Builder()
                .baseUrl("https://pokeapi.co/api/v2/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        obtenerInfo();
    }

    private void obtenerInfo() {
        pokemonService service = retrofit.create(pokemonService.class);
        Call<pokemonRespuesta> pokemonRespuestaCall = service.obtenerListaPokemon();

        pokemonRespuestaCall.enqueue(new Callback<pokemonRespuesta>() {
            @Override
            public void onResponse(Call<pokemonRespuesta> call, Response<pokemonRespuesta> response) {
                if(response.isSuccessful()){
                    pokemonRespuesta pokemonRespuesta = response.body();
                    ArrayList<Pokemon> listapokemon = pokemonRespuesta.getResults();

                    for (int i = 0; i < listapokemon.size(); i++) {
                        Pokemon p = listapokemon.get(i);
                        Log.i(TAG, "Pokemon: " + p.getName());
                    }
                } else {
                    Log.e(TAG, "onResponse:" + response.errorBody());
                }
            }

            @Override
            public void onFailure(Call<pokemonRespuesta> call, Throwable t) {
                Log.e(TAG, "onFailure: " + t.getMessage());
            }
        });
    }

}